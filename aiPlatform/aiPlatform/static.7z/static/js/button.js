    $('login').click(function () {
        location.href = '/admin/login'
    })
    $('signin').click(function () {
        location.href = '/signin'
    })
